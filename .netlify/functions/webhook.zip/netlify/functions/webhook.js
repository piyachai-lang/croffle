// netlify/functions/webhook.js
exports.handler = async function(event) {
  if (event.httpMethod !== "POST") {
    return { statusCode: 200, body: "LINE Webhook OK" };
  }
  try {
    const body = JSON.parse(event.body || "{}");
    const events = body.events || [];
    const token = process.env.LINE_CHANNEL_ACCESS_TOKEN;
    if (!token) return { statusCode: 200, body: "ok" };
    for (const e of events) {
      if (e.type === "message" && e.source && e.replyToken) {
        const userId = e.source.userId || "\u0E44\u0E21\u0E48\u0E1E\u0E1A";
        await fetch("https://api.line.me/v2/bot/message/reply", {
          method: "POST",
          headers: {
            "Authorization": "Bearer " + token,
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            replyToken: e.replyToken,
            messages: [{
              type: "text",
              text: "\u{1F194} User ID \u0E02\u0E2D\u0E07\u0E04\u0E38\u0E13\u0E04\u0E37\u0E2D:\n" + userId + "\n\n\u0E19\u0E33\u0E44\u0E1B\u0E27\u0E32\u0E07\u0E43\u0E19 LINE_OWNER_USER_ID_2 \u0E43\u0E19 Netlify \u0E44\u0E14\u0E49\u0E40\u0E25\u0E22\u0E04\u0E48\u0E30"
            }]
          })
        });
      }
    }
    return { statusCode: 200, body: "ok" };
  } catch (err) {
    console.error("Webhook error:", err);
    return { statusCode: 200, body: "ok" };
  }
};
