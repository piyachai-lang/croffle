// netlify/functions/notify.js
exports.handler = async function(event) {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Content-Type": "application/json"
  };
  try {
    const body = JSON.parse(event.body || "{}");
    const { message, order } = body;
    const token = process.env.LINE_CHANNEL_ACCESS_TOKEN;
    const userId1 = process.env.LINE_OWNER_USER_ID;
    const userId2 = process.env.LINE_OWNER_USER_ID_2;
    if (!token || !userId1) {
      console.warn("LINE config not set \u2014 skipping notification");
      return { statusCode: 200, headers, body: JSON.stringify({ status: "skipped" }) };
    }
    const userIds = [userId1, userId2].filter(Boolean);
    const flexMsg = buildFlexMessage(order || {}, message || "");
    const results = await Promise.all(userIds.map(
      (uid) => fetch("https://api.line.me/v2/bot/message/push", {
        method: "POST",
        headers: {
          "Authorization": "Bearer " + token,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ to: uid, messages: [flexMsg] })
      }).then((r) => ({ uid, ok: r.ok, status: r.status }))
    ));
    console.log("LINE push results:", JSON.stringify(results));
    return { statusCode: 200, headers, body: JSON.stringify({ results }) };
  } catch (err) {
    console.error("LINE Messaging API error:", err);
    return { statusCode: 500, headers, body: JSON.stringify({ error: String(err) }) };
  }
};
function buildFlexMessage(order, fallbackText) {
  const items = Array.isArray(order.items) ? order.items : Object.values(order.items || {});
  const name = order.customerName || "\u0E44\u0E21\u0E48\u0E23\u0E30\u0E1A\u0E38\u0E0A\u0E37\u0E48\u0E2D";
  const time = order.time || "";
  const total = order.totRev || 0;
  const note = order.note || "";
  const itemRows = items.map((i) => ({
    type: "box",
    layout: "horizontal",
    contents: [
      { type: "text", text: i.name + " \xD7" + i.qty, size: "sm", color: "#555555", flex: 3, wrap: true },
      { type: "text", text: "\u0E3F" + i.sell * i.qty, size: "sm", color: "#111111", align: "end", flex: 1, weight: "bold" }
    ],
    paddingBottom: "4px"
  }));
  const noteSection = note ? [
    { type: "separator", margin: "md" },
    {
      type: "box",
      layout: "horizontal",
      margin: "md",
      contents: [
        { type: "text", text: "\u{1F4DD}", size: "sm", flex: 0 },
        { type: "text", text: note, size: "sm", color: "#E65100", wrap: true, margin: "sm" }
      ]
    }
  ] : [];
  return {
    type: "flex",
    altText: "\u{1F6D2} \u0E2D\u0E2D\u0E40\u0E14\u0E2D\u0E23\u0E4C\u0E43\u0E2B\u0E21\u0E48\u0E08\u0E32\u0E01 " + name + " \u0E3F" + total,
    contents: {
      type: "bubble",
      header: {
        type: "box",
        layout: "vertical",
        paddingAll: "14px",
        backgroundColor: "#3D1F07",
        contents: [
          {
            type: "box",
            layout: "horizontal",
            contents: [
              { type: "text", text: "\u{1F6D2} \u0E2D\u0E2D\u0E40\u0E14\u0E2D\u0E23\u0E4C\u0E43\u0E2B\u0E21\u0E48!", color: "#F5A623", size: "lg", weight: "bold", flex: 1 },
              { type: "text", text: "\u{1F550} " + time, color: "#ffffff99", size: "sm", align: "end", gravity: "center" }
            ]
          },
          { type: "text", text: "\u{1F464} " + name, color: "#ffffffcc", size: "md", margin: "xs" }
        ]
      },
      body: {
        type: "box",
        layout: "vertical",
        paddingAll: "14px",
        contents: [
          ...itemRows,
          { type: "separator", margin: "md" },
          {
            type: "box",
            layout: "horizontal",
            margin: "md",
            contents: [
              { type: "text", text: "\u0E23\u0E27\u0E21\u0E17\u0E31\u0E49\u0E07\u0E2B\u0E21\u0E14", size: "md", weight: "bold", color: "#3D1F07", flex: 1 },
              { type: "text", text: "\u0E3F" + total, size: "lg", weight: "bold", color: "#2E7D32", align: "end" }
            ]
          },
          ...noteSection
        ]
      }
    }
  };
}
